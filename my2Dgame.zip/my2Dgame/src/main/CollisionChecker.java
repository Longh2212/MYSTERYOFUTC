// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// 
//                 _ooOoo_                       NAM MÔ A DI ĐÀ PHẬT !
//                o8888888o
//                88" . "88      Thí chủ con tên là Long Hoàng, dương lịch 'hai mươi bẩy tháng ba năm 2024'
//                (| 😑 |)      Ngụ tại số nhà '21 Lê Văn Lương,Nhân Chính, Thanh Xuân, Hà Nội'
//                 O\ = /O
//             ____/`---'\____         Con lạy chín phương trời, con lạy mười phương đất
//             .' \\| |// `.             Chư Phật mười phương, mười phương chư Phật
//            / \\||| : |||// \        Con ơn nhờ Trời đất chổ che, Thánh Thần cứu độ
//          / _||||| -:- |||||- \    Xin nhất tâm kính lễ Hoàng thiên Hậu thổ, Tiên Phật Thánh Thần
//            | | \\\ - /// | |              Giúp đỡ con code sạch ít bug
//          | \_| ''\---/'' | |           Đồng nghiệp vui vẻ, sếp quý tăng lương
//          \ .-\__ `-` ___/-. /          Sức khoẻ dồi dào, tiền vào như nước
//        ___`. .' /--.--\ `. . __
//     ."" '< `.___\_<|>_/___.' >'"". NAM MÔ VIÊN THÔNG GIÁO CHỦ ĐẠI TỪ ĐẠI BI TẦM THANH CỨU KHỔ CỨU NẠN
//    | | : `- \`.;`\ _ /`;.`/ - ` : | |  QUẢNG ĐẠI LINH CẢM QUÁN THẾ ÂM BỒ TÁT
//      \ \ `-. \_ __\ /__ _/ .-` / /
// ======`-.____`-.___\_____/___.-`____.-'======
//                 `=---='
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
package src.main;
import src.entity.Entity;

public class CollisionChecker {
    private GamePanel gp;
    public CollisionChecker(GamePanel gp){
        this.gp = gp;
    }
        public void checkTile(Entity entity){
            
            int entityLeftWorldX = entity.worldX + entity.solidArea.x; 
            int entityRightWorldX = entity.worldX + entity.solidArea.x + entity.solidArea.width;
            int entityTopWorldY = entity.worldY + entity.solidArea.y;
            int entityBottomWorldY = entity.worldY + entity.solidArea.y + entity.solidArea.width;

            int entityLeftCol = entityLeftWorldX/gp.tilesize;
            int entityRightCol = entityRightWorldX/gp.tilesize;
            int entityTopRow = entityTopWorldY/gp.tilesize;
            int entityBottomRow = entityBottomWorldY/gp.tilesize;


            int tileNum1, tileNum2, tileNum3;

            switch (entity.direction) {
                case "up":
                    entityTopRow = (entityTopWorldY - entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                    tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                    if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                        entity.collisionUp = true;
                    }
                    break;
                case "down":
                    entityBottomRow = (entityBottomWorldY + entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                    tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                    if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                        entity.collisionDown = true;
                    }
                    break;
                case "left":
                    entityLeftCol = (entityLeftWorldX - entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                    tileNum2 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                    if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                        entity.collisionLeft = true;
                    }
                    break;
                case "right":
                    entityRightCol = (entityRightWorldX + entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                    tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                    if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true){
                        entity.collisionRight = true;
                    }
                    break;
                case "upright":
                    entityTopRow = (entityTopWorldY - entity.speed)/gp.tilesize;
                    entityRightCol = (entityRightWorldX + entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                    tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                    tileNum3 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                    if(gp.tileM.tile[tileNum1].collision == false &&( gp.tileM.tile[tileNum2].collision == true || gp.tileM.tile[tileNum3].collision == true)){
                        entity.collisionRight = true;

                    }
                    if((gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true )&& gp.tileM.tile[tileNum3].collision == false){
                        entity.collisionUp = true;
                    }
                    if(gp.tileM.tile[tileNum1].collision == true && gp.tileM.tile[tileNum3].collision == true){
                        entity.collisionOn = true;
                    }        
                    break;
                case "downright":
                    entityBottomRow = (entityBottomWorldY + entity.speed)/gp.tilesize;
                    entityRightCol = (entityRightWorldX + entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                    tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                    tileNum3 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                    if(gp.tileM.tile[tileNum1].collision == false &&( gp.tileM.tile[tileNum2].collision == true || gp.tileM.tile[tileNum3].collision == true)){
                        entity.collisionRight = true;

                    }
                    if((gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true )&& gp.tileM.tile[tileNum3].collision == false){
                        entity.collisionDown = true;
                    }
                    if(gp.tileM.tile[tileNum1].collision == true && gp.tileM.tile[tileNum3].collision == true){
                        entity.collisionOn = true;
                    }    
                    break;
                case "upleft":
                    entityTopRow = (entityTopWorldY - entity.speed)/gp.tilesize;
                    entityLeftCol = (entityLeftWorldX - entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                    tileNum2 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                    tileNum3 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                    if(gp.tileM.tile[tileNum1].collision == false &&( gp.tileM.tile[tileNum2].collision == true || gp.tileM.tile[tileNum3].collision == true)){
                        entity.collisionLeft = true;

                    }
                    if((gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true )&& gp.tileM.tile[tileNum3].collision == false){
                        entity.collisionUp = true;
                    }
                    if(gp.tileM.tile[tileNum1].collision == true && gp.tileM.tile[tileNum3].collision == true){
                        entity.collisionOn = true;
                    }    
                    break;
                case "downleft":  
                    entityBottomRow = (entityBottomWorldY + entity.speed)/gp.tilesize;
                    entityLeftCol = (entityLeftWorldX - entity.speed)/gp.tilesize;
                    tileNum1 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                    tileNum2 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                    tileNum3 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                    if(gp.tileM.tile[tileNum1].collision == false &&( gp.tileM.tile[tileNum2].collision == true || gp.tileM.tile[tileNum3].collision == true)){
                        entity.collisionLeft = true;
                    }
                    if((gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true )&& gp.tileM.tile[tileNum3].collision == false){
                        entity.collisionDown = true;
                    }
                    if(gp.tileM.tile[tileNum1].collision == true && gp.tileM.tile[tileNum3].collision == true){
                        entity.collisionOn = true;
                    }    
                    break;                  
            }

        }
}
