package src.entity;

import src.main.GamePanel;
import src.main.KeyHandle;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
// import java.awt.Color;
public class Player  extends Entity{
    
    final int originalTitlesize = 16; // 16*16 tittle
    final int scale = 3;

    public final int screenX;
    public final int screenY;

    GamePanel gp;
    KeyHandle KeyH;
    public Player(GamePanel gp, KeyHandle keyH){
        this.gp = gp;
        this.KeyH = keyH;

        screenX = gp.screenWidth/2 - (gp.tilesize/2);
        screenY = gp.screenHeight/2 -(gp.tilesize/2);

        solidArea = new Rectangle(8,16,32,32);

        setDefaultValues();
        getPlayerImage();
    }
    public void setDefaultValues(){
        worldX=gp.tilesize * 9;
        worldY=gp.tilesize *10;
        speed = 3;
        direction = "down";
    }
    public void getPlayerImage(){

        try{
            up1    = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_up_1.png"));
            up2    = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_up_2.png"));
            down1  = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_down_1.png"));
            down2  = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_down_2.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_right_1.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_right_2.png"));
            left1  = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_left_1.png"));
            left2  = ImageIO.read(getClass().getResourceAsStream("/res/player/boy_left_2.png"));
        }catch(IOException e){
            e.printStackTrace();
        }
    } 
    public double range = 1/Math.sqrt(2);
    public void move(){
        
    }
    public void update(){
        if( KeyH.up == true || KeyH.down == true || KeyH.right== true || KeyH.left == true){
            if( KeyH.up == true && KeyH.left == true){
                direction = "upleft";

            }
            else if( KeyH.down == true && KeyH.left == true){
                direction = "downleft";

            }
            else if( KeyH.up == true && KeyH.right == true){
                direction = "upright";

            }
            else if( KeyH.down == true && KeyH.right == true){
                direction = "downright";

            }
            else if( KeyH.up == true){
                direction = "up";
            }
            else if(KeyH.down == true){
                direction = "down";

            }
            else if(KeyH.right == true){
                direction = "right";

            }
            else if (KeyH.left == true){
                direction = "left";

            }
            // CHECK COLLISION
            collisionOn = false;
            collisionRight=false;
            collisionUp=false;
            collisionDown=false;
            collisionLeft=false;

            gp.cChecker.checkTile(this);
            
            // IF COLLISION IS FALSE, PLAY CAN MOVE
            // if(collisionUp == false){

            // }
    
            if(collisionOn == true){
                switch (direction) {
                    case "up":
                        
                        break;
                
                    default:
                        break;
                }
            }
    if(collisionOn == false){
        switch (direction) {
            case "up": 
                if(collisionUp == false) worldY -= speed; 
                break;
            case "down": 
                if(collisionDown == false) worldY += speed; 
                break;
            case "left": 
                if(collisionLeft == false) worldX -= speed; 
                break;
            case "right": 
                if(collisionRight == false) worldX += speed; 
                break;
            case "upleft":
                if(collisionUp == true) worldX -= (speed-1);
                else if(collisionLeft == true) worldY -= (speed-1);
                if(collisionUp == false && collisionLeft == false){
                    worldX -= (speed-1);
                    worldY -= (speed-1);}
                break;
            case "downleft":
                if(collisionDown == true ) worldX -= (speed-1);
                else if(collisionLeft == true) worldY += (speed-1);
                else{
                    worldX -= (speed-1);
                    worldY += (speed-1);
                }
                break;
            case "upright":
                if(collisionUp == true ) { worldX += (speed-1);}
                else if(collisionRight == true) worldY -= (speed-1);        
                else{
                    worldY -= (speed-1);
                    worldX += (speed-1);
                }    
                break;
            case "downright":
                if(collisionDown == true) worldX += (speed-1);
                else if(collisionRight) worldY += (speed-1);
                else{
                    worldX += (speed-1);
                    worldY += (speed-1); 
                }
                
                break;
        }
    }
            spriteCounter++;
            if(spriteCounter > 12){
                if(spriteNum == 1){
                    spriteNum = 2;
                }
                else if (spriteNum == 2){
                    spriteNum = 1;
                }
                spriteCounter =0;
            }
        }
    }
    public void draw(Graphics2D g2){
        //  g2.setColor(Color.green);
        // g2.fillRect(screenX , screenY, gp.tilesize, gp.tilesize);

        BufferedImage image = null;
         switch (direction) {
            case "upleft":
                if(spriteNum == 1){
                    image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                    break;
            case "downleft":
                if(spriteNum == 1){
                    image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                    break;
            case "upright":
                if(spriteNum == 1){
                    image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }  
                    break;
            case "downright":
                if(spriteNum == 1){
                    image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }  
                    break;
            case "up":
                if(spriteNum == 1){
                    image = up1;
                }
                if(spriteNum == 2){
                    image = up2;
                }
                    break;
            case "down":
                if(spriteNum == 1){
                    image = down1;
                }
                if(spriteNum == 2){
                    image = down2;
                } 
                    break;
            case "right":
                if(spriteNum == 1){
                    image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }  
                    break;
            case "left":
                if(spriteNum == 1){
                    image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                    break;
         }
         g2.drawImage(image,screenX, screenY, gp.tilesize,gp.tilesize,null);
    }
}
